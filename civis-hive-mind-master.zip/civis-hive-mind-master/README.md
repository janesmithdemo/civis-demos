# civis-hive-mind
a Shiny app to map the skills that Civis employees possess and want to develop.
